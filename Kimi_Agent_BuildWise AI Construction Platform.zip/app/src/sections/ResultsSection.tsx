import { useRef, useLayoutEffect } from 'react';
import { TrendingDown, TrendingUp, Users } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  {
    icon: TrendingDown,
    value: '-18%',
    label: 'schedule variance',
    description: 'Tighter sequencing, fewer surprises.',
  },
  {
    icon: TrendingDown,
    value: '-12%',
    label: 'cost overrun risk',
    description: 'Early alerts keep budgets on track.',
  },
  {
    icon: TrendingUp,
    value: '+22%',
    label: 'resource utilization',
    description: 'Right crew, right time, less idle time.',
  },
];

const testimonials = [
  {
    quote:
      'We cut planning time by half—and caught a delay risk two weeks earlier than usual.',
    author: 'Director of Planning',
    company: 'Mid-Size GC',
  },
  {
    quote:
      'The cost forecasts are the most accurate we\'ve seen—our PMs actually trust the numbers.',
    author: 'VP of Operations',
    company: 'Regional Contractor',
  },
];

export function ResultsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const testimonialsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const statsEl = statsRef.current;
    const testimonialsEl = testimonialsRef.current;

    if (!section || !headline || !statsEl || !testimonialsEl) return;

    const ctx = gsap.context(() => {
      // Headline reveal
      gsap.fromTo(
        headline,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: headline,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Stats cards stagger
      const statCards = statsEl.querySelectorAll('.stat-card');
      gsap.fromTo(
        statCards,
        { y: 60, scale: 0.98, opacity: 0 },
        {
          y: 0,
          scale: 1,
          opacity: 1,
          duration: 0.7,
          stagger: 0.12,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: statsEl,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Testimonials
      const testimonialCards = testimonialsEl.querySelectorAll('.testimonial-card');
      gsap.fromTo(
        testimonialCards[0],
        { x: -60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: testimonialsEl,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        testimonialCards[1],
        { x: 60, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: testimonialsEl,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="results"
      className="relative bg-navy blueprint-grid py-24 lg:py-32"
      style={{ zIndex: 110 }}
    >
      <div className="w-full px-6 lg:px-12">
        {/* Headline */}
        <div ref={headlineRef} className="max-w-2xl mb-16">
          <h2 className="font-display font-bold text-3xl lg:text-4xl xl:text-5xl text-white uppercase tracking-tight mb-4">
            Proven <span className="text-cyan">Results</span>
          </h2>
          <p className="text-white/70 text-lg">
            Teams using BuildWise finish more predictably—and protect margin.
          </p>
        </div>

        {/* Stats Grid */}
        <div
          ref={statsRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16"
        >
          {stats.map((stat, index) => (
            <div
              key={index}
              className="stat-card bg-secondary/50 border border-white/10 rounded-xl p-6 lg:p-8 hover:border-cyan/30 transition-colors"
            >
              <stat.icon className="w-8 h-8 text-cyan mb-4" />
              <div className="font-display font-bold text-4xl lg:text-5xl text-white mb-2">
                {stat.value}
              </div>
              <div className="font-mono-label text-xs tracking-wider text-cyan uppercase mb-2">
                {stat.label}
              </div>
              <p className="text-white/60 text-sm">{stat.description}</p>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div
          ref={testimonialsRef}
          className="grid grid-cols-1 lg:grid-cols-2 gap-6"
        >
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="testimonial-card bg-secondary/30 border border-white/10 rounded-xl p-6 lg:p-8"
            >
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-cyan/20 flex items-center justify-center flex-shrink-0">
                  <Users className="w-5 h-5 text-cyan" />
                </div>
                <div>
                  <p className="text-white/90 text-base lg:text-lg leading-relaxed mb-4 italic">
                    "{testimonial.quote}"
                  </p>
                  <div className="text-sm">
                    <span className="text-white font-medium">
                      {testimonial.author}
                    </span>
                    <span className="text-white/50"> — {testimonial.company}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

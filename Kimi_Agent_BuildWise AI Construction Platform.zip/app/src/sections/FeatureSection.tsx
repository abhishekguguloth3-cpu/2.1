import { useRef, useLayoutEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface FeatureSectionProps {
  id?: string;
  label: string;
  headline: string;
  body: string;
  cta: string;
  imageSrc: string;
  imagePosition: 'left' | 'right';
  imageAspect?: '16:9' | '3:4';
  zIndex: number;
}

export function FeatureSection({
  id,
  label,
  headline,
  body,
  cta,
  imageSrc,
  imagePosition,
  imageAspect = '16:9',
  zIndex,
}: FeatureSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const underlineRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const dividerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const labelEl = labelRef.current;
    const underline = underlineRef.current;
    const headlineEl = headlineRef.current;
    const bodyEl = bodyRef.current;
    const divider = dividerRef.current;

    if (!section || !image || !labelEl || !underline || !headlineEl || !bodyEl) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Image entrance (0-30%)
      const imageStartX = imagePosition === 'left' ? '-60vw' : '60vw';
      const imageExitX = imagePosition === 'left' ? '-18vw' : '18vw';
      
      scrollTl.fromTo(
        image,
        { x: imageStartX, scale: 1.06, opacity: 0 },
        { x: 0, scale: 1, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.to(image, { ease: 'none' }, 0.3);

      // Divider line (for 50/50 sections)
      if (divider) {
        scrollTl.fromTo(
          divider,
          { scaleY: 0 },
          { scaleY: 1, ease: 'none' },
          0
        );
        scrollTl.to(divider, { ease: 'none' }, 0.3);
      }

      // Label entrance (5-30%)
      scrollTl.fromTo(
        labelEl,
        { y: -20, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.05
      );
      scrollTl.to(labelEl, { ease: 'none' }, 0.3);

      // Underline scale (5-30%)
      scrollTl.fromTo(
        underline,
        { scaleX: 0 },
        { scaleX: 1, ease: 'none' },
        0.05
      );
      scrollTl.to(underline, { ease: 'none' }, 0.3);

      // Headline entrance (10-30%)
      const words = headlineEl.querySelectorAll('.headline-word span');
      scrollTl.fromTo(
        words,
        { y: 60, opacity: 0 },
        { y: 0, opacity: 1, stagger: 0.02, ease: 'none' },
        0.1
      );
      scrollTl.to(headlineEl, { ease: 'none' }, 0.3);

      // Body entrance (15-30%)
      scrollTl.fromTo(
        bodyEl,
        { y: 30, opacity: 0 },
        { y: 0, opacity: 1, ease: 'none' },
        0.15
      );
      scrollTl.to(bodyEl, { ease: 'none' }, 0.3);

      // EXIT animations (70-100%)
      scrollTl.fromTo(
        image,
        { x: 0, opacity: 1 },
        { x: imageExitX, opacity: 0.25, ease: 'power2.in' },
        0.7
      );

      if (divider) {
        scrollTl.fromTo(
          divider,
          { scaleY: 1 },
          { scaleY: 0, ease: 'power2.in' },
          0.7
        );
      }

      scrollTl.fromTo(
        labelEl,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        underline,
        { opacity: 1 },
        { opacity: 0, ease: 'power2.in' },
        0.75
      );

      scrollTl.fromTo(
        headlineEl,
        { y: 0, opacity: 1 },
        { y: -24, opacity: 0, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        bodyEl,
        { y: 0, opacity: 1 },
        { y: -16, opacity: 0, ease: 'power2.in' },
        0.74
      );
    }, section);

    return () => ctx.revert();
  }, [imagePosition]);

  const isLeftImage = imagePosition === 'left';
  const imageWidth = imageAspect === '3:4' ? (isLeftImage ? '50vw' : '46vw') : (isLeftImage ? '55vw' : '48vw');
  const contentLeft = isLeftImage ? '58vw' : '6vw';
  const contentWidth = isLeftImage ? '36vw' : '40vw';
  const labelLeft = isLeftImage ? '58vw' : '6vw';

  return (
    <section
      ref={sectionRef}
      id={id}
      className="section-pinned bg-navy blueprint-grid"
      style={{ zIndex }}
    >
      {/* Vertical Divider (for 50/50 sections) */}
      {imageAspect === '3:4' && (
        <div
          ref={dividerRef}
          className="absolute left-1/2 top-0 w-px h-full bg-white/12 origin-top"
          style={{ transform: 'scaleY(0)' }}
        />
      )}

      {/* Image */}
      <div
        ref={imageRef}
        className={`absolute top-0 h-full cyan-ink-overlay ${
          isLeftImage ? 'left-0' : 'right-0'
        }`}
        style={{ width: imageWidth }}
      >
        <img
          src={imageSrc}
          alt={headline}
          className="w-full h-full object-cover grayscale"
        />
      </div>

      {/* Label */}
      <div
        ref={labelRef}
        className="absolute font-mono-label text-xs tracking-[0.12em] text-cyan uppercase"
        style={{ left: labelLeft, top: '10vh' }}
      >
        {label}
      </div>

      {/* Accent Underline */}
      <div
        ref={underlineRef}
        className="absolute h-0.5 bg-cyan origin-left"
        style={{ left: labelLeft, top: '14vh', width: '10vw' }}
      />

      {/* Content */}
      <div
        className="absolute top-[22vh] flex flex-col"
        style={{ left: contentLeft, width: contentWidth }}
      >
        {/* Headline */}
        <h2
          ref={headlineRef}
          className="font-display font-bold text-3xl lg:text-4xl xl:text-5xl text-white uppercase leading-[1.05] tracking-tight mb-6"
        >
          {headline.split(' ').map((word, i) => (
            <span key={i} className="headline-word inline-block mr-[0.3em]">
              <span>{word}</span>
            </span>
          ))}
        </h2>

        {/* Body */}
        <div ref={bodyRef}>
          <p className="text-white/70 text-base lg:text-lg leading-relaxed mb-6">
            {body}
          </p>
          <button className="group flex items-center gap-2 text-cyan hover:text-cyan-light transition-colors">
            <span className="text-sm font-medium">{cta}</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  );
}

import { useRef, useLayoutEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, MessageCircle } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function CTASection() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const content = contentRef.current;

    if (!section || !image || !content) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=120%',
          pin: true,
          scrub: 0.6,
        },
      });

      // Image entrance (0-30%)
      scrollTl.fromTo(
        image,
        { scale: 1.08, opacity: 0 },
        { scale: 1, opacity: 1, ease: 'none' },
        0
      );
      scrollTl.to(image, { ease: 'none' }, 0.3);

      // Content entrance (0-30%)
      const headline = content.querySelector('h2');
      const subhead = content.querySelector('p');
      const ctas = content.querySelector('.cta-row');

      if (headline) {
        const words = headline.querySelectorAll('.headline-word span');
        scrollTl.fromTo(
          words,
          { y: 70, opacity: 0 },
          { y: 0, opacity: 1, stagger: 0.03, ease: 'none' },
          0
        );
        scrollTl.to(headline, { ease: 'none' }, 0.3);
      }

      if (subhead) {
        scrollTl.fromTo(
          subhead,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.1
        );
        scrollTl.to(subhead, { ease: 'none' }, 0.3);
      }

      if (ctas) {
        scrollTl.fromTo(
          ctas,
          { y: 30, opacity: 0 },
          { y: 0, opacity: 1, ease: 'none' },
          0.15
        );
        scrollTl.to(ctas, { ease: 'none' }, 0.3);
      }

      // EXIT animations (70-100%)
      scrollTl.fromTo(
        image,
        { scale: 1, opacity: 1 },
        { scale: 1.03, opacity: 0.35, ease: 'power2.in' },
        0.7
      );

      if (headline) {
        scrollTl.fromTo(
          headline,
          { y: 0, opacity: 1 },
          { y: -18, opacity: 0, ease: 'power2.in' },
          0.7
        );
      }

      if (subhead) {
        scrollTl.fromTo(
          subhead,
          { y: 0, opacity: 1 },
          { y: -12, opacity: 0, ease: 'power2.in' },
          0.72
        );
      }

      if (ctas) {
        scrollTl.fromTo(
          ctas,
          { y: 0, opacity: 1 },
          { y: -10, opacity: 0, ease: 'power2.in' },
          0.74
        );
      }
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="cta"
      className="section-pinned bg-navy"
      style={{ zIndex: 120 }}
    >
      {/* Background Image */}
      <div
        ref={imageRef}
        className="absolute inset-0 cyan-ink-overlay"
      >
        <img
          src="/cta_site.jpg"
          alt="Construction site at dusk"
          className="w-full h-full object-cover grayscale"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/70 to-navy/40" />
      </div>

      {/* Content */}
      <div
        ref={contentRef}
        className="absolute inset-0 flex flex-col items-center justify-center text-center px-6"
      >
        <h2 className="font-display font-bold text-4xl lg:text-5xl xl:text-6xl text-white uppercase tracking-tight mb-6">
          <span className="headline-word">
            <span>Ready</span>
          </span>{' '}
          <span className="headline-word">
            <span>to</span>
          </span>{' '}
          <span className="headline-word">
            <span>Build</span>
          </span>{' '}
          <span className="headline-word">
            <span className="text-cyan">Smarter?</span>
          </span>
        </h2>

        <p className="text-white/70 text-lg lg:text-xl max-w-2xl mb-8">
          Get a demo and see how BuildWise can plan your next project in minutes.
        </p>

        <div className="cta-row flex flex-wrap gap-4 justify-center">
          <Button
            size="lg"
            className="bg-cyan text-navy-dark hover:bg-cyan-light font-semibold px-8"
            onClick={scrollToContact}
          >
            Request a demo
            <ArrowRight className="ml-2 w-5 h-5" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 hover:border-white/50"
            onClick={scrollToContact}
          >
            <MessageCircle className="mr-2 w-5 h-5" />
            Talk to sales
          </Button>
        </div>

        <p className="text-white/50 text-sm mt-8">
          No commitment. Our team will reply within 1 business day.
        </p>
      </div>
    </section>
  );
}

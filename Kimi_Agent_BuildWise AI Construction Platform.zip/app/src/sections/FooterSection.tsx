import { useRef, useLayoutEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Mail, MapPin, Phone, Send } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function FooterSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const form = formRef.current;

    if (!section || !left || !form) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        left,
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        form,
        { y: 60, scale: 0.98, opacity: 0 },
        {
          y: 0,
          scale: 1,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: section,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({ name: '', email: '', company: '', message: '' });
    }, 3000);
  };

  return (
    <footer
      ref={sectionRef}
      id="contact"
      className="relative bg-navy py-24 lg:py-32"
      style={{ zIndex: 130 }}
    >
      <div className="w-full px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left Column - Contact Info */}
          <div ref={leftRef}>
            <h2 className="font-display font-bold text-3xl lg:text-4xl text-white uppercase tracking-tight mb-6">
              <span className="text-cyan">Contact</span>
            </h2>
            <p className="text-white/70 text-lg mb-10 max-w-md">
              Have a question or a complex project? We're happy to walk through
              it.
            </p>

            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-cyan/10 flex items-center justify-center">
                  <Mail className="w-5 h-5 text-cyan" />
                </div>
                <div>
                  <div className="font-mono-label text-xs tracking-wider text-white/50 uppercase mb-1">
                    Email
                  </div>
                  <a
                    href="mailto:hello@buildwise.ai"
                    className="text-white hover:text-cyan transition-colors"
                  >
                    hello@buildwise.ai
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-cyan/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-cyan" />
                </div>
                <div>
                  <div className="font-mono-label text-xs tracking-wider text-white/50 uppercase mb-1">
                    Office
                  </div>
                  <span className="text-white">
                    1200 Construction Plaza, Suite 400
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-lg bg-cyan/10 flex items-center justify-center">
                  <Phone className="w-5 h-5 text-cyan" />
                </div>
                <div>
                  <div className="font-mono-label text-xs tracking-wider text-white/50 uppercase mb-1">
                    Phone
                  </div>
                  <a
                    href="tel:+15550142200"
                    className="text-white hover:text-cyan transition-colors"
                  >
                    +1 (555) 014-2200
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Form */}
          <div
            ref={formRef}
            className="bg-secondary/50 border border-white/10 rounded-xl p-6 lg:p-8"
          >
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 rounded-full bg-cyan/20 flex items-center justify-center mb-4">
                  <Send className="w-8 h-8 text-cyan" />
                </div>
                <h3 className="font-display font-bold text-xl text-white mb-2">
                  Message Sent!
                </h3>
                <p className="text-white/60">
                  We'll get back to you within 1 business day.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-mono-label text-xs tracking-wider text-white/50 uppercase mb-2">
                      Name
                    </label>
                    <Input
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      placeholder="Your name"
                      className="bg-navy/50 border-white/10 text-white placeholder:text-white/30 focus:border-cyan"
                      required
                    />
                  </div>
                  <div>
                    <label className="block font-mono-label text-xs tracking-wider text-white/50 uppercase mb-2">
                      Email
                    </label>
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) =>
                        setFormData({ ...formData, email: e.target.value })
                      }
                      placeholder="your@email.com"
                      className="bg-navy/50 border-white/10 text-white placeholder:text-white/30 focus:border-cyan"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-mono-label text-xs tracking-wider text-white/50 uppercase mb-2">
                    Company
                  </label>
                  <Input
                    value={formData.company}
                    onChange={(e) =>
                      setFormData({ ...formData, company: e.target.value })
                    }
                    placeholder="Your company"
                    className="bg-navy/50 border-white/10 text-white placeholder:text-white/30 focus:border-cyan"
                  />
                </div>

                <div>
                  <label className="block font-mono-label text-xs tracking-wider text-white/50 uppercase mb-2">
                    Message
                  </label>
                  <Textarea
                    value={formData.message}
                    onChange={(e) =>
                      setFormData({ ...formData, message: e.target.value })
                    }
                    placeholder="Tell us about your project..."
                    rows={4}
                    className="bg-navy/50 border-white/10 text-white placeholder:text-white/30 focus:border-cyan resize-none"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  className="w-full bg-cyan text-navy-dark hover:bg-cyan-light font-semibold"
                >
                  <Send className="mr-2 w-4 h-4" />
                  Send message
                </Button>
              </form>
            )}
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="mt-16 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="font-display font-bold text-lg text-white">
              Build<span className="text-cyan">Wise</span>
            </div>
            <div className="flex items-center gap-6">
              <a
                href="#"
                className="text-sm text-white/50 hover:text-cyan transition-colors"
              >
                Privacy
              </a>
              <a
                href="#"
                className="text-sm text-white/50 hover:text-cyan transition-colors"
              >
                Terms
              </a>
              <a
                href="#"
                className="text-sm text-white/50 hover:text-cyan transition-colors"
              >
                Security
              </a>
              <a
                href="#"
                className="text-sm text-white/50 hover:text-cyan transition-colors"
              >
                Careers
              </a>
            </div>
            <div className="text-sm text-white/40">
              © 2026 BuildWise. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { useRef, useLayoutEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLDivElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const subheadRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const image = imageRef.current;
    const label = labelRef.current;
    const headline = headlineRef.current;
    const subhead = subheadRef.current;
    const cta = ctaRef.current;

    if (!section || !image || !label || !headline || !subhead || !cta) return;

    const ctx = gsap.context(() => {
      // Auto-play entrance animation on load
      const loadTl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Image entrance
      loadTl.fromTo(
        image,
        { scale: 1.08, x: '-6vw', opacity: 0 },
        { scale: 1, x: 0, opacity: 1, duration: 1.1 }
      );

      // Label entrance
      loadTl.fromTo(
        label,
        { y: -12, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        '-=0.7'
      );

      // Headline words entrance
      const words = headline.querySelectorAll('.headline-word span');
      loadTl.fromTo(
        words,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.06 },
        '-=0.4'
      );

      // Subheadline entrance
      loadTl.fromTo(
        subhead,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.7 },
        '-=0.3'
      );

      // CTA entrance
      loadTl.fromTo(
        cta,
        { y: 20, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6 },
        '-=0.4'
      );

      // Scroll-driven exit animation
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset all elements when scrolling back to top
            gsap.set([label, headline, subhead, cta], { opacity: 1, y: 0 });
            gsap.set(image, { opacity: 1, x: 0 });
          },
        },
      });

      // Exit animations (70% - 100%)
      scrollTl.fromTo(
        label,
        { opacity: 1, y: 0 },
        { opacity: 0, y: -18, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        headline,
        { opacity: 1, y: 0 },
        { opacity: 0, y: -28, ease: 'power2.in' },
        0.7
      );

      scrollTl.fromTo(
        subhead,
        { opacity: 1, y: 0 },
        { opacity: 0, y: -16, ease: 'power2.in' },
        0.72
      );

      scrollTl.fromTo(
        cta,
        { opacity: 1, y: 0 },
        { opacity: 0, y: -16, ease: 'power2.in' },
        0.74
      );

      scrollTl.fromTo(
        image,
        { opacity: 1, x: 0 },
        { opacity: 0.25, x: '-10vw', ease: 'power2.in' },
        0.7
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      className="section-pinned bg-navy blueprint-grid z-10"
    >
      {/* Hero Image */}
      <div
        ref={imageRef}
        className="absolute left-0 top-0 w-[62vw] h-full cyan-ink-overlay"
      >
        <img
          src="/hero_site.jpg"
          alt="Construction site"
          className="w-full h-full object-cover grayscale"
        />
      </div>

      {/* Content */}
      <div className="absolute left-[62vw] top-0 w-[38vw] h-full flex flex-col justify-center px-8 lg:px-12">
        {/* Micro Label */}
        <div
          ref={labelRef}
          className="font-mono-label text-xs tracking-[0.12em] text-cyan uppercase mb-6"
        >
          Generative Construction Planning
        </div>

        {/* Headline */}
        <h1
          ref={headlineRef}
          className="font-display font-bold text-4xl lg:text-5xl xl:text-6xl text-white uppercase leading-[0.95] tracking-tight mb-6"
        >
          <span className="headline-word">
            <span>Plan</span>
          </span>{' '}
          <span className="headline-word">
            <span>Smarter.</span>
          </span>
          <br />
          <span className="headline-word">
            <span>Build</span>
          </span>{' '}
          <span className="headline-word">
            <span className="text-cyan">Faster.</span>
          </span>
        </h1>

        {/* Subheadline */}
        <p
          ref={subheadRef}
          className="text-white/70 text-base lg:text-lg leading-relaxed max-w-md mb-8"
        >
          AI-generated schedules, cost forecasts, and resource plans—built from
          your project inputs and historical data.
        </p>

        {/* CTAs */}
        <div ref={ctaRef} className="flex flex-wrap gap-4">
          <Button
            className="bg-cyan text-navy-dark hover:bg-cyan-light font-semibold px-6"
            onClick={() => scrollToSection('cta')}
          >
            Request a demo
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            className="border-white/30 text-white hover:bg-white/10 hover:border-white/50"
            onClick={() => scrollToSection('features')}
          >
            See how it works
          </Button>
        </div>
      </div>
    </section>
  );
}

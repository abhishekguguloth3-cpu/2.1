import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-navy/90 backdrop-blur-md border-b border-white/10'
          : 'bg-transparent'
      }`}
    >
      <div className="w-full px-6 lg:px-12 h-16 flex items-center justify-between">
        <div className="font-display font-bold text-xl text-white tracking-tight">
          Build<span className="text-cyan">Wise</span>
        </div>
        
        <div className="hidden md:flex items-center gap-8">
          <button
            onClick={() => scrollToSection('features')}
            className="text-sm text-white/70 hover:text-cyan transition-colors"
          >
            Product
          </button>
          <button
            onClick={() => scrollToSection('solutions')}
            className="text-sm text-white/70 hover:text-cyan transition-colors"
          >
            Solutions
          </button>
          <button
            onClick={() => scrollToSection('results')}
            className="text-sm text-white/70 hover:text-cyan transition-colors"
          >
            Pricing
          </button>
          <button
            onClick={() => scrollToSection('contact')}
            className="text-sm text-white/70 hover:text-cyan transition-colors"
          >
            Contact
          </button>
        </div>
        
        <Button
          variant="outline"
          className="border-cyan/50 text-cyan hover:bg-cyan/10 hover:border-cyan text-sm"
          onClick={() => scrollToSection('cta')}
        >
          Request demo
        </Button>
      </div>
    </nav>
  );
}

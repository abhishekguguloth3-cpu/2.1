import { useEffect, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Navigation } from '@/components/Navigation';
import { HeroSection } from '@/sections/HeroSection';
import { FeatureSection } from '@/sections/FeatureSection';
import { ResultsSection } from '@/sections/ResultsSection';
import { CTASection } from '@/sections/CTASection';
import { FooterSection } from '@/sections/FooterSection';

gsap.registerPlugin(ScrollTrigger);

// Feature sections data
const featureSections = [
  {
    id: 'featured',
    label: 'Featured Project',
    headline: 'Delivered On Time, On Budget.',
    body: 'A 34-story mixed-use tower planned with BuildWise—optimized sequencing, reduced waste, and real-time risk alerts from day one.',
    cta: 'Read the case study →',
    imageSrc: '/featured_highrise.jpg',
    imagePosition: 'left' as const,
    imageAspect: '3:4' as const,
    zIndex: 20,
  },
  {
    id: 'approach',
    label: 'Our Approach',
    headline: 'Predict. Optimize. Deliver.',
    body: 'We combine your project inputs with historical performance to generate schedules, costs, and resource plans—then refine them as conditions change.',
    cta: 'Explore the methodology →',
    imageSrc: '/approach_steel.jpg',
    imagePosition: 'right' as const,
    imageAspect: '3:4' as const,
    zIndex: 30,
  },
  {
    id: 'features',
    label: 'AI Planning Engine',
    headline: 'Generate Plans In Minutes.',
    body: 'Turn requirements into detailed schedules, cost forecasts, and resource allocations—automatically adjusted for constraints and risks.',
    cta: 'See a sample plan →',
    imageSrc: '/planning_crane.jpg',
    imagePosition: 'left' as const,
    imageAspect: '16:9' as const,
    zIndex: 40,
  },
  {
    id: 'solutions',
    label: 'Smart Scheduling',
    headline: 'Keep Every Phase On Track.',
    body: 'Auto-generated timelines with buffer-aware sequencing, dependency mapping, and delay predictions—so you can act before problems stack.',
    cta: 'Explore scheduling →',
    imageSrc: '/scheduling_pour.jpg',
    imagePosition: 'right' as const,
    imageAspect: '16:9' as const,
    zIndex: 50,
  },
  {
    id: 'cost',
    label: 'Cost Intelligence',
    headline: 'Forecast Spend. Control Margin.',
    body: 'AI-generated cost breakdowns based on scope, location, and market trends—with alerts when estimates drift from target.',
    cta: 'See cost features →',
    imageSrc: '/cost_rebar.jpg',
    imagePosition: 'left' as const,
    imageAspect: '16:9' as const,
    zIndex: 60,
  },
  {
    id: 'resource',
    label: 'Resource Optimization',
    headline: 'Right Crew. Right Time.',
    body: 'Match labor and equipment to tasks based on availability, skills, and location—minimizing idle time and overtime.',
    cta: 'Learn more →',
    imageSrc: '/resource_worker.jpg',
    imagePosition: 'right' as const,
    imageAspect: '16:9' as const,
    zIndex: 70,
  },
  {
    id: 'risk',
    label: 'Risk & Quality Control',
    headline: 'Catch Issues Early.',
    body: 'Detect schedule risks, cost overruns, and compliance gaps before they impact the field—powered by historical patterns and real-time signals.',
    cta: 'Explore risk tools →',
    imageSrc: '/risk_welding.jpg',
    imagePosition: 'left' as const,
    imageAspect: '16:9' as const,
    zIndex: 80,
  },
  {
    id: 'collab',
    label: 'Collaboration Hub',
    headline: 'One Source Of Truth.',
    body: 'Share plans, updates, and decisions with owners, contractors, and subs—without losing context in email threads.',
    cta: 'See collaboration features →',
    imageSrc: '/collab_meeting.jpg',
    imagePosition: 'right' as const,
    imageAspect: '16:9' as const,
    zIndex: 90,
  },
  {
    id: 'insights',
    label: 'Real-Time Insights',
    headline: 'Know Where You Stand.',
    body: 'Live dashboards track progress, spend, and risks—so you can adjust plans quickly and report with confidence.',
    cta: 'View dashboard preview →',
    imageSrc: '/insights_control.jpg',
    imagePosition: 'left' as const,
    imageAspect: '16:9' as const,
    zIndex: 100,
  },
];

function App() {
  // Global scroll snap for pinned sections
  useEffect(() => {
    // Wait for all ScrollTriggers to be created
    const timeout = setTimeout(() => {
      const pinned = ScrollTrigger.getAll()
        .filter((st) => st.vars.pin)
        .sort((a, b) => a.start - b.start);

      const maxScroll = ScrollTrigger.maxScroll(window);

      if (!maxScroll || pinned.length === 0) return;

      // Build ranges and snap targets from pinned sections
      const pinnedRanges = pinned.map((st) => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }));

      // Create global snap
      ScrollTrigger.create({
        snap: {
          snapTo: (value) => {
            // Check if within any pinned range (with small buffer)
            const inPinned = pinnedRanges.some(
              (r) => value >= r.start - 0.02 && value <= r.end + 0.02
            );
            if (!inPinned) return value; // Flowing section: free scroll

            // Find nearest pinned center
            const target = pinnedRanges.reduce(
              (closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value)
                  ? r.center
                  : closest,
              pinnedRanges[0]?.center ?? 0
            );
            return target;
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out',
        },
      });
    }, 100);

    return () => {
      clearTimeout(timeout);
    };
  }, []);

  // Refresh ScrollTrigger on resize
  useLayoutEffect(() => {
    const handleResize = () => {
      ScrollTrigger.refresh();
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="relative bg-navy min-h-screen">
      {/* Grain Overlay */}
      <div className="grain-overlay" />

      {/* Navigation */}
      <Navigation />

      {/* Main Content */}
      <main className="relative">
        {/* Hero Section */}
        <HeroSection />

        {/* Feature Sections */}
        {featureSections.map((section) => (
          <FeatureSection key={section.id} {...section} />
        ))}

        {/* Results Section (flowing) */}
        <ResultsSection />

        {/* CTA Section */}
        <CTASection />

        {/* Footer Section */}
        <FooterSection />
      </main>
    </div>
  );
}

export default App;
